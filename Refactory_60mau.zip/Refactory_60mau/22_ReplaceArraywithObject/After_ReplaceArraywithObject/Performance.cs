﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace After_ReplaceArraywithObject
{
    public class Performance
    {
        public string Name { get; set; }
        public int Wins { get; set; }
    }
}
