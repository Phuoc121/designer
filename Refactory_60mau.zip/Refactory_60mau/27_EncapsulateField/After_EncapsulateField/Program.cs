﻿class Program
{
    static void Main()
    {
        Person person = new Person();
        person.SetName("Alice");
        Console.WriteLine(person.GetName());
    }
}
